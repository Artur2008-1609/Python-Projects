import json

def carregar_dados(caminho_arquivo):
    try:
        with open(caminho_arquivo, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
            print("Erro! Arquivo fretePROVA_B.json não encontrado.")
            return None