from datetime import datetime
import leitura_banco
import main

def iniciar_sistema():
    agora = datetime.now()
    print("\n")
    print("="*40)
    print(f"Sistema acessado em: {agora.strftime('%d/%m/%Y %H:%M:%S')}")
    print("="*40)

if __name__ == "__main__":
    iniciar_sistema()