from leitura_banco import carregar_dados
from datetime import datetime
from datetimedaslocalizacoes import iniciar_sistema
paises_lista = carregar_dados('fretePROVA_B.json')

def menu():

    print("\n-=- PLANEJAMENTO DE VIAGENS -=-")
    print("  1 - Mostrar cidades disponiveis")
    print("  2 - Data e hora das cidades")
    print("-=============================-")


def main():

    while True:
        menu()
        opcao = int(input("\nEscolha uma das opções: "))

        if opcao == 1:
            print("\n")
            print(paises_lista)

        elif opcao == 2:
            iniciar_sistema()

        else:
            print("\nError! digitalização invalida")
            


