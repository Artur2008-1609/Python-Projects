import interface

if __name__ == "__main__":
    print("Iniciando Sistema...")
    interface.main()