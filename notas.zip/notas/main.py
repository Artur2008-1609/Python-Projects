import csv
import os
from datetime import datetime

filename = "dados_notas.csv"
campos = ["Aluno", "Nota", "Hora"]

nome = input("Nome do aluno: ")
nota = input("Digite a nota: ")
hora = datetime.now().strftime('%d-%m-%Y %H:%M:$S')

novo_registro = {
    "Aluno": nome,
    "Nota": nota,
    "Hora": hora,
}

filename = r'H:\Python\notas\dados_notas.csv'
arquivo_existente = os.path.isfile(filename)

with open(filename, 'a', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=campos)

    if not arquivo_existente:
         writer.writerheader()

    writer.writerow(novo_registro)

print(f"Dados de {nome} salvos com sucesso!") 