import streamlit as st
import pandas as pd

st.set_page_config(page_title="Caixa de Supermercado", page_icon="🛒", layout="wide")

produtos = {
    "Azeite": {"preco": 29.90, "estoque": 10, "categoria": "Mercearia"},
    "Molho de Tomate": {"preco": 14.90, "estoque": 15, "categoria": "Mercearia"},
    "Alface": {"preco": 5.50, "estoque": 8, "categoria": "Hortifrúti"},
    "Tomate": {"preco": 7.50, "estoque": 20, "categoria": "Hortifrúti"},
    "Pó de Café": {"preco": 19.90, "estoque": 12, "categoria": "Mercearia"},
    "Leite": {"preco": 6.90, "estoque": 30, "categoria": "Laticínios"},
    "Biscoito": {"preco": 9.90, "estoque": 25, "categoria": "Snacks"},
    "Picanha": {"preco": 72.00, "estoque": 5, "categoria": "Açougue"},
}

for item in produtos:
    if f"qtd_{item}" not in st.session_state:
        st.session_state[f"qtd_{item}"] = 0

def limpar_carrinho():
    for item in produtos:
        st.session_state[f"qtd_{item}"] = 0

def finalizar_compra():
    st.session_state["compra_sucesso"] = True
    limpar_carrinho()

st.title("🛒 Sistema de Caixa de Supermercado")
st.markdown("Selecione a quantidade desejada de cada item para adicionar ao carrinho.")

if st.session_state.get("compra_sucesso"):
    st.success("Compra realizada com sucesso!")
    st.session_state["compra_sucesso"] = False

# Layout Principal
col_catalogo, col_carrinho = st.columns([1.8, 1.2], gap="large")

with col_catalogo:
    st.header("📦 Catálogo de Produtos")
    
    col_a, col_b = st.columns(2)
    
    for i, (nome_item, info) in enumerate(produtos.items()):
        coluna_destino = col_a if i % 2 == 0 else col_b
        
        with coluna_destino:
            with st.container(border=True):
                st.subheader(nome_item)
                st.caption(f"Categoria: {info['categoria']}")
                st.write(f"**Preço:** R\\$ {info['preco']:.2f}")
                st.write(f"**Estoque disponível:** {info['estoque']} un.")
                
                st.number_input(
                    label="Quantidade",
                    min_value=0,
                    max_value=info["estoque"],
                    step=1,
                    key=f"qtd_{nome_item}",
                    label_visibility="collapsed"
                )

with col_carrinho:
    st.header("🛒 Carrinho de Compras")
    
    itens_no_carrinho = []
    total_compra = 0.0
    total_itens_qtd = 0

    for item, info in produtos.items():
        qtd = st.session_state[f"qtd_{item}"]
        if qtd > 0:
            subtotal = info["preco"] * qtd
            total_compra += subtotal
            total_itens_qtd += qtd
            itens_no_carrinho.append({
                "Produto": item,
                "Qtd": qtd,
                "Preço Unit.": f"R\\$ {info['preco']:.2f}",
                "Subtotal": f"R\\$ {subtotal:.2f}"
            })

    if itens_no_carrinho:
        df_carrinho = pd.DataFrame(itens_no_carrinho)
        st.dataframe(df_carrinho, use_container_width=True, hide_index=True)
        
        st.divider()
        
        m_col1, m_col2 = st.columns(2)
        m_col1.metric("Total de Itens", f"{total_itens_qtd} un.")
        m_col2.metric("Valor Total", f"R\\$ {total_compra:.2f}")
        
        st.divider()

        btn_col1, btn_col2 = st.columns(2)
        with btn_col1:
            st.button(
                "❌ Limpar Carrinho", 
                use_container_width=True, 
                type="secondary",
                on_click=limpar_carrinho
            )
        with btn_col2:
            st.button(
                "✅ Finalizar Compra", 
                use_container_width=True, 
                type="primary",
                on_click=finalizar_compra
            )
    else:
        st.info("O carrinho está vazio. Adicione unidades dos produtos no catálogo para ver o resumo.")